package it.univaq.disim.SortMap;


import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

class ValueComparator implements Comparator<String> {

    Map<String, Double> base;
    public ValueComparator(Map<String, Double> base) {
        this.base = base;
    }

    // Note: this comparator imposes orderings that are inconsistent with equals.    
    public int compare(String a, String b) {
        if (base.get(a) >= base.get(b)) {
            return -1;
        } else {
            return 1;
        } // returning 0 would merge keys
    }
}



public class Runner {

	public Runner(){
		
	}
		
	public void run(){			
		sortAMap();		
	}
		
	public void sortAMap(){
						
		Map<String, Double> recommendations = new HashMap<String, Double>();
		
		recommendations.put("A", 3.0);
		recommendations.put("B", 2.0);
		recommendations.put("C", 4.0);
		recommendations.put("D", 1.0);
		recommendations.put("E", 0.0);
		recommendations.put("A", 8.0);
				
		ValueComparator bvc =  new ValueComparator(recommendations);        
		TreeMap<String,Double> sorted_map = new TreeMap<String,Double>(bvc);
		sorted_map.putAll(recommendations);				
		Set<String> keySet = sorted_map.keySet();				
	
		System.out.println("Sort the map in descending order!");
		for(String key:keySet) {
			System.out.println(key + "\t" + recommendations.get(key));
		}
		
		return;
	}
		
	public static void main(String[] args) {	
		Runner runner = new Runner();			
		runner.run();				    		    
		return;
	}	
	
}
